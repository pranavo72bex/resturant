import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

const sooper = TextStyle(
  color: Colors.black,
  fontWeight: FontWeight.bold,
  fontSize: 24,
);
const bodytext = TextStyle(
  color: Colors.black,
  fontWeight: FontWeight.bold,
  fontSize: 26,
);
const link = TextStyle(
  color: Colors.blue,
  fontWeight: FontWeight.w900,
  fontSize: 24,
);
